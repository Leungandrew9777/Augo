import reflex as rx
import pandas as pd
import joblib
import json
import os
from typing import Any

# ── Constants ─────────────────────────────────────────────────────────────────

PL_TEAMS: list[str] = sorted([
    "Arsenal", "Aston Villa", "Bournemouth", "Brentford",
    "Brighton & Hove Albion", "Burnley", "Chelsea", "Crystal Palace",
    "Everton", "Fulham", "Leeds United", "Liverpool", "Manchester City",
    "Manchester United", "Newcastle", "Nottingham Forest", "Sunderland",
    "Tottenham Hotspur", "West Ham United", "Wolverhampton Wanderers",
])

# Club badge URLs from the Premier League CDN (FPL team IDs)
TEAM_BADGES: dict[str, str] = {
    "Arsenal":                    "https://resources.premierleague.com/premierleague/badges/t3.png",
    "Aston Villa":                "https://resources.premierleague.com/premierleague/badges/t7.png",
    "Bournemouth":                "https://resources.premierleague.com/premierleague/badges/t91.png",
    "Brentford":                  "https://resources.premierleague.com/premierleague/badges/t94.png",
    "Brighton & Hove Albion":     "https://resources.premierleague.com/premierleague/badges/t36.png",
    "Burnley":                    "https://resources.premierleague.com/premierleague/badges/t90.png",
    "Chelsea":                    "https://resources.premierleague.com/premierleague/badges/t8.png",
    "Crystal Palace":             "https://resources.premierleague.com/premierleague/badges/t31.png",
    "Everton":                    "https://resources.premierleague.com/premierleague/badges/t11.png",
    "Fulham":                     "https://resources.premierleague.com/premierleague/badges/t54.png",
    "Leeds United":               "https://resources.premierleague.com/premierleague/badges/t2.png",
    "Liverpool":                  "https://resources.premierleague.com/premierleague/badges/t14.png",
    "Manchester City":            "https://resources.premierleague.com/premierleague/badges/t43.png",
    "Manchester United":          "https://resources.premierleague.com/premierleague/badges/t1.png",
    "Newcastle":                  "https://resources.premierleague.com/premierleague/badges/t4.png",
    "Nottingham Forest":          "https://resources.premierleague.com/premierleague/badges/t17.png",
    "Sunderland":                 "https://resources.premierleague.com/premierleague/badges/t56.png",
    "Tottenham Hotspur":          "https://resources.premierleague.com/premierleague/badges/t6.png",
    "West Ham United":            "https://resources.premierleague.com/premierleague/badges/t21.png",
    "Wolverhampton Wanderers":    "https://resources.premierleague.com/premierleague/badges/t39.png",
}

FALLBACK_BADGE = "https://resources.premierleague.com/premierleague/badges/t0.png"

FALLBACK_FIXTURES: list[dict] = [
    {"idx": 0, "date": "2026-04-11", "home_team": "West Ham United",     "away_team": "Wolverhampton Wanderers"},
    {"idx": 1, "date": "2026-04-11", "home_team": "Arsenal",             "away_team": "Bournemouth"},
    {"idx": 2, "date": "2026-04-11", "home_team": "Brentford",           "away_team": "Everton"},
    {"idx": 3, "date": "2026-04-11", "home_team": "Burnley",             "away_team": "Brighton & Hove Albion"},
    {"idx": 4, "date": "2026-04-12", "home_team": "Liverpool",           "away_team": "Fulham"},
    {"idx": 5, "date": "2026-04-12", "home_team": "Crystal Palace",      "away_team": "Newcastle"},
    {"idx": 6, "date": "2026-04-12", "home_team": "Nottingham Forest",   "away_team": "Aston Villa"},
    {"idx": 7, "date": "2026-04-12", "home_team": "Sunderland",          "away_team": "Tottenham Hotspur"},
    {"idx": 8, "date": "2026-04-12", "home_team": "Chelsea",             "away_team": "Manchester City"},
    {"idx": 9, "date": "2026-04-14", "home_team": "Manchester United",   "away_team": "Leeds United"},
]

from typing import TypedDict

class MatchDict(TypedDict):
    home_team: str
    away_team: str
    badge_home: str
    badge_away: str
    disp_odds_home: str
    disp_odds_draw: str
    disp_odds_away: str
    disp_prob_home: str
    disp_prob_draw: str
    disp_prob_away: str
    prob_home: float
    prob_draw: float
    prob_away: float
    fair_odds_home: float
    fair_odds_draw: float
    fair_odds_away: float
    actual: str

class GWDict(TypedDict):
    idx: int
    gw: str
    date: str
    matches: list[MatchDict]
    accuracy: str
    pnl: str
    pnl_positive: bool

class FixtureDict(TypedDict):
    idx: int
    date: str
    home_team: str
    away_team: str

class PredictionDict(TypedDict):
    home_team: str
    away_team: str
    badge_home: str
    badge_away: str
    disp_odds_home: str
    disp_odds_draw: str
    disp_odds_away: str
    disp_prob_home: str
    disp_prob_draw: str
    disp_prob_away: str
    prob_home: float
    prob_draw: float
    prob_away: float
    fair_odds_home: float
    fair_odds_draw: float
    fair_odds_away: float
    disp_elo_diff: str
    chart_label: str

class ChartBarDict(TypedDict):
    label: str
    home: float
    draw: float
    away: float

class EloChartDict(TypedDict):
    label: str
    elo_diff: float
    elo_positive: bool

# ── State ─────────────────────────────────────────────────────────────────────

class State(rx.State):
    current_tab: str = "home"

    # Matchweek
    fixtures: list[dict[str, Any]] = FALLBACK_FIXTURES
    predictions: list[dict[str, Any]] = []
    gameweek_label: str = "GW32"

    # Custom predictor
    custom_home: str = PL_TEAMS[0]
    custom_away: str = PL_TEAMS[1]
    custom_result: list[dict[str, Any]] = []

    # Insights (pre-computed on load)
    safe_picks: list[dict[str, Any]] = []      # prob_best > 0.65
    coin_flips: list[dict[str, Any]] = []      # all probs between 0.28–0.40
    top_pick: dict[str, Any] = {}              # highest single win prob
    underdog: dict[str, Any] = {}              # lowest favourite prob that won prediction
    win_prob_chart: list[dict[str, Any]] = []  # [{label, home, draw, away}]
    elo_chart: list[dict[str, Any]] = []       # [{label, elo_diff}]

    # History  ── saved gameweeks with optional actual results
    history: list[dict[str, Any]] = []         # [{gw, date, matches: [...], accuracy, pnl}]
    history_selected: int = -1        # index into history being viewed

    # ── Fixtures ──────────────────────────────────────────────────────────────

    def _reindex(self):
        for i, f in enumerate(self.fixtures):
            f["idx"] = i

    def load_fixtures_from_csv(self):
        """
        Read fixtures.csv if present; falls back to FALLBACK_FIXTURES.
        CSV format:  date,home_team,away_team[,gameweek]
        """
        path = "fixtures.csv"
        if os.path.exists(path):
            try:
                df = pd.read_csv(path)
                rows = []
                for i, row in df.iterrows():
                    rows.append({
                        "idx": int(i),
                        "date": str(row["date"]),
                        "home_team": str(row["home_team"]),
                        "away_team": str(row["away_team"]),
                    })
                if rows:
                    self.fixtures = rows
                    if "gameweek" in df.columns:
                        self.gameweek_label = str(df["gameweek"].iloc[0])
            except Exception:
                self.fixtures = FALLBACK_FIXTURES
        else:
            self.fixtures = FALLBACK_FIXTURES

    def add_fixture(self):
        self.fixtures.append({"idx": len(self.fixtures), "date": "", "home_team": "", "away_team": ""})

    def delete_fixture(self, idx: int):
        self.fixtures = [f for f in self.fixtures if f["idx"] != idx]
        self._reindex()

    def update_date(self, idx: int, value: str):
        self.fixtures[idx]["date"] = value

    def update_home_fixture(self, idx: int, value: str):
        self.fixtures[idx]["home_team"] = value

    def update_away_fixture(self, idx: int, value: str):
        self.fixtures[idx]["away_team"] = value

    # ── ML pipeline ──────────────────────────────────────────────────────────

    def _load_model_and_elo(self):
        model = joblib.load("xgboost_premier_league_model.pkl")
        df_elo = pd.read_csv("premier_league_with_elo_best.csv")
        df_elo["date"] = pd.to_datetime(df_elo["date"])
        return model, df_elo

    def _compute_current_elo(self, upcoming: pd.DataFrame, df_elo: pd.DataFrame) -> pd.DataFrame:
        latest_elo: dict = {}
        for team in pd.concat([df_elo["home_team"], df_elo["away_team"]]).unique():
            m = df_elo[(df_elo["home_team"] == team) | (df_elo["away_team"] == team)]
            if len(m) > 0:
                last = m.sort_values("date").iloc[-1]
                latest_elo[team] = last["elo_home_before"] if last["home_team"] == team else last["elo_away_before"]
            else:
                latest_elo[team] = 1500.0
        upcoming["elo_home"] = upcoming["home_team"].map(latest_elo).fillna(1500.0)
        upcoming["elo_away"] = upcoming["away_team"].map(latest_elo).fillna(1500.0)
        upcoming["elo_diff"] = upcoming["elo_home"] - upcoming["elo_away"]
        return upcoming

    def _predict_upcoming(self, upcoming: pd.DataFrame, df_elo: pd.DataFrame, model) -> pd.DataFrame:
        for window in [5, 10]:
            upcoming[f"home_win_rate_{window}"] = upcoming["home_team"].apply(
                lambda t: df_elo[df_elo["home_team"] == t].tail(window)["result"].eq("H").mean()
                if len(df_elo[df_elo["home_team"] == t]) > 0 else 0.5)
            upcoming[f"home_draw_rate_{window}"] = upcoming["home_team"].apply(
                lambda t: df_elo[df_elo["home_team"] == t].tail(window)["result"].eq("D").mean()
                if len(df_elo[df_elo["home_team"] == t]) > 0 else 0.3)
            upcoming[f"away_win_rate_{window}"] = upcoming["away_team"].apply(
                lambda t: df_elo[df_elo["away_team"] == t].tail(window)["result"].eq("A").mean()
                if len(df_elo[df_elo["away_team"] == t]) > 0 else 0.5)
            upcoming[f"away_draw_rate_{window}"] = upcoming["away_team"].apply(
                lambda t: df_elo[df_elo["away_team"] == t].tail(window)["result"].eq("D").mean()
                if len(df_elo[df_elo["away_team"] == t]) > 0 else 0.3)
        upcoming["h2h_home_win_rate"] = 0.5

        feature_cols = ["elo_diff", "home_win_rate_5", "home_win_rate_10",
                        "away_win_rate_5", "away_win_rate_10",
                        "home_draw_rate_5", "away_draw_rate_5", "h2h_home_win_rate"]
        probs = model.predict_proba(upcoming[feature_cols])

        upcoming["prob_home"]      = probs[:, 0]
        upcoming["prob_draw"]      = probs[:, 1]
        upcoming["prob_away"]      = probs[:, 2]
        upcoming["fair_odds_home"] = 1 / upcoming["prob_home"]
        upcoming["fair_odds_draw"] = 1 / upcoming["prob_draw"]
        upcoming["fair_odds_away"] = 1 / upcoming["prob_away"]

        # Pre-format display strings — never do arithmetic on Reflex Vars
        upcoming["disp_odds_home"] = upcoming["fair_odds_home"].map(lambda v: f"{v:.3g}")
        upcoming["disp_odds_draw"] = upcoming["fair_odds_draw"].map(lambda v: f"{v:.3g}")
        upcoming["disp_odds_away"] = upcoming["fair_odds_away"].map(lambda v: f"{v:.3g}")
        upcoming["disp_prob_home"] = upcoming["prob_home"].map(lambda v: f"{v*100:.1f}%")
        upcoming["disp_prob_draw"] = upcoming["prob_draw"].map(lambda v: f"{v*100:.1f}%")
        upcoming["disp_prob_away"] = upcoming["prob_away"].map(lambda v: f"{v*100:.1f}%")
        upcoming["disp_elo_diff"]  = upcoming["elo_diff"].map(lambda v: f"{v:+.0f}")
        upcoming["badge_home"]     = upcoming["home_team"].map(lambda t: TEAM_BADGES.get(t, FALLBACK_BADGE))
        upcoming["badge_away"]     = upcoming["away_team"].map(lambda t: TEAM_BADGES.get(t, FALLBACK_BADGE))
        # Short label for charts  e.g. "WHU v ARS"
        upcoming["chart_label"]    = upcoming.apply(
            lambda r: r["home_team"][:3].upper() + " v " + r["away_team"][:3].upper(), axis=1)
        return upcoming

    def _compute_insights(self, df: pd.DataFrame):
        records = df.to_dict("records")

        # Safe picks: highest single-outcome probability > 0.65
        self.safe_picks = [
            r for r in records
            if max(r["prob_home"], r["prob_draw"], r["prob_away"]) > 0.65
        ]

        # Coin flips: all three outcomes between 0.22 and 0.45
        self.coin_flips = [
            r for r in records
            if all(0.22 <= p <= 0.45 for p in [r["prob_home"], r["prob_draw"], r["prob_away"]])
        ]

        # Top pick: match with the highest single win probability (home or away)
        best = max(records, key=lambda r: max(r["prob_home"], r["prob_away"]), default={})
        self.top_pick = best

        # Biggest underdog: match where the away team has the highest raw probability
        # but the elo_diff most favours home (away is still predicted to win at decent odds)
        underdogs = [r for r in records if r["prob_away"] > r["prob_home"]]
        if underdogs:
            self.underdog = min(underdogs, key=lambda r: r["prob_away"])
        elif records:
            self.underdog = max(records, key=lambda r: r["fair_odds_away"])
        else:
            self.underdog = {}

        # Chart data
        self.win_prob_chart = [
            {
                "label": r["chart_label"],
                "home":  round(r["prob_home"] * 100, 1),
                "draw":  round(r["prob_draw"] * 100, 1),
                "away":  round(r["prob_away"] * 100, 1),
            }
            for r in records
        ]
        # AFTER
        self.elo_chart = [
            {"label": r["chart_label"], "elo_diff": round(r["elo_diff"], 0),
             "elo_positive": bool(r["elo_diff"] >= 0)}
            for r in records
        ]

    def load_predictions(self):
        self.load_fixtures_from_csv()
        try:
            model, df_elo = self._load_model_and_elo()
            raw = [{k: v for k, v in f.items() if k != "idx"} for f in self.fixtures]
            upcoming = pd.DataFrame(raw)
            upcoming["date"] = pd.to_datetime(upcoming["date"])
            upcoming = self._compute_current_elo(upcoming, df_elo)
            upcoming = self._predict_upcoming(upcoming, df_elo, model)
            self.predictions = upcoming.to_dict("records")
            self._compute_insights(upcoming)
        except Exception as e:
            return rx.toast.error(f"Prediction error: {e}")

    # ── Custom predictor ──────────────────────────────────────────────────────

    def run_custom_prediction(self):
        if self.custom_home == self.custom_away:
            return rx.toast.error("Pick two different teams.")
        try:
            model, df_elo = self._load_model_and_elo()
            df = pd.DataFrame([{
                "date": str(pd.Timestamp.today().date()),
                "home_team": self.custom_home,
                "away_team": self.custom_away,
            }])
            df["date"] = pd.to_datetime(df["date"])
            df = self._compute_current_elo(df, df_elo)
            df = self._predict_upcoming(df, df_elo, model)
            self.custom_result = df.to_dict("records")
        except Exception as e:
            return rx.toast.error(f"Prediction error: {e}")

    # ── History ───────────────────────────────────────────────────────────────

    def save_to_history(self):
        if not self.predictions:
            return rx.toast.error("No predictions to save.")
        matches = [
            {
                "home_team":    p["home_team"],
                "away_team":    p["away_team"],
                "badge_home":   p["badge_home"],
                "badge_away":   p["badge_away"],
                "disp_odds_home": p["disp_odds_home"],
                "disp_odds_draw": p["disp_odds_draw"],
                "disp_odds_away": p["disp_odds_away"],
                "disp_prob_home": p["disp_prob_home"],
                "disp_prob_draw": p["disp_prob_draw"],
                "disp_prob_away": p["disp_prob_away"],
                "prob_home":    p["prob_home"],
                "prob_draw":    p["prob_draw"],
                "prob_away":    p["prob_away"],
                "fair_odds_home": p["fair_odds_home"],
                "fair_odds_draw": p["fair_odds_draw"],
                "fair_odds_away": p["fair_odds_away"],
                "actual":       "",  # filled in later
            }
            for p in self.predictions
        ]
        entry = {
            "idx":      len(self.history),
            "gw":       self.gameweek_label,
            "date":     self.fixtures[0]["date"] if self.fixtures else "",
            "matches":  matches,
            "accuracy": "",
            "pnl":      "",
            "pnl_positive": False,
        }
        self.history.append(entry)
        return rx.toast.success(f"{self.gameweek_label} saved to history.")

    def select_history(self, idx: int):
        self.history_selected = idx

    def set_actual_result(self, gw_idx: int, match_idx: int, result: str):
        """Mark actual result (H/D/A) and recalculate accuracy + P&L."""
        self.history[gw_idx]["matches"][match_idx]["actual"] = result
        self._recalculate_history(gw_idx)

    def _recalculate_history(self, gw_idx: int):
        matches = self.history[gw_idx]["matches"]
        completed = [m for m in matches if m["actual"] in ("H", "D", "A")]
        if not completed:
            self.history[gw_idx]["accuracy"] = ""
            self.history[gw_idx]["pnl"] = ""
            return

        correct = 0
        pnl = 0.0
        for m in completed:
            # Predicted outcome = highest probability
            pred = max(
                [("H", m["prob_home"]), ("D", m["prob_draw"]), ("A", m["prob_away"])],
                key=lambda x: x[1]
            )[0]
            if pred == m["actual"]:
                correct += 1
            # Flat £1 stake on predicted outcome
            odds_map = {"H": m["fair_odds_home"], "D": m["fair_odds_draw"], "A": m["fair_odds_away"]}
            if pred == m["actual"]:
                pnl += odds_map[pred] - 1.0
            else:
                pnl -= 1.0

        acc = correct / len(completed) * 100
        self.history[gw_idx]["accuracy"] = f"{acc:.0f}%  ({correct}/{len(completed)})"
        sign = "+" if pnl >= 0 else ""
        self.history[gw_idx]["pnl"] = f"{sign}{pnl:.2f} u"
        self.history[gw_idx]["pnl_positive"] = bool(pnl >= 0)


# ── Shared UI helpers ─────────────────────────────────────────────────────────

def badge_img(url, size: str = "28px") -> rx.Component:
    return rx.image(src=url, width=size, height=size,
                    style={"object_fit": "contain", "flex_shrink": "0"})


def odds_col(label: str, odds, prob, color: str) -> rx.Component:
    return rx.vstack(
        rx.text(label, color="#555",  font_size="0.65em", letter_spacing="0.1em", font_weight="600"),
        rx.text(odds,  color=color,   font_size="1.5em",  font_weight="700",       line_height="1"),
        rx.text(prob,  color="#555",  font_size="0.74em"),
        spacing="1",
        align="center",
        width="33%",
    )


def match_card(p: dict) -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.hstack(
                badge_img(p["badge_home"]),
                rx.text(p["home_team"], font_weight="600", font_size="0.82em",
                        color="#d0d0d0", flex="1", text_align="right"),
                rx.text("v", color="#2a2a2a", font_size="0.7em", padding_x="8px"),
                rx.text(p["away_team"], font_weight="600", font_size="0.82em",
                        color="#d0d0d0", flex="1"),
                badge_img(p["badge_away"]),
                width="100%",
                align="center",
            ),
            rx.box(height="1px", width="100%", background_color="#1e1e1e"),
            rx.hstack(
                odds_col("H", p["disp_odds_home"], p["disp_prob_home"], "#4CAF50"),
                odds_col("D", p["disp_odds_draw"], p["disp_prob_draw"], "#FFC107"),
                odds_col("A", p["disp_odds_away"], p["disp_prob_away"], "#F44336"),
                width="100%",
                justify="between",
            ),
            spacing="3",
            align="center",
            width="100%",
        ),
        width="100%",
        padding="13px 14px",
        background_color="#141414",
        border_radius="8px",
        border="1px solid #1e1e1e",
    )


def section_label(text: str) -> rx.Component:
    return rx.text(text, color="#555", font_size="0.68em",
                   letter_spacing="0.12em", font_weight="700",
                   padding_bottom="4px")


# ── Home tab ──────────────────────────────────────────────────────────────────

def home_tab() -> rx.Component:
    return rx.vstack(
        rx.cond(
            State.predictions.length() > 0,
            rx.vstack(
                rx.hstack(
                    section_label(State.gameweek_label),
                    rx.spacer(),
                    rx.box(
                        rx.text("Save to History", color="#888", font_size="0.7em"),
                        on_click=State.save_to_history,
                        padding="4px 10px",
                        border="1px solid #2a2a2a",
                        border_radius="4px",
                        cursor="pointer",
                    ),
                    width="100%",
                    align="center",
                    padding_bottom="6px",
                ),
                rx.foreach(State.predictions.to(list[dict[str, Any]]), match_card),
                width="100%",
                spacing="2",
            ),
            rx.box(
                rx.text("Loading predictions…", color="#444", font_size="0.88em"),
                text_align="center", padding_y="48px", width="100%",
            ),
        ),
        width="100%",
        spacing="2",
    )


# ── Predictor tab (dropdowns) ─────────────────────────────────────────────────

def predictor_tab() -> rx.Component:
    select_style = {
        "background_color": "#141414",
        "color": "white",
        "border": "1px solid #2a2a2a",
        "border_radius": "6px",
        "width": "100%",
    }
    return rx.vstack(
        section_label("CUSTOM FIXTURE"),
        rx.select(
            PL_TEAMS,
            value=State.custom_home,
            on_change=State.set_custom_home,
            placeholder="Home team",
            style=select_style,
            width="100%",
        ),
        rx.select(
            PL_TEAMS,
            value=State.custom_away,
            on_change=State.set_custom_away,
            placeholder="Away team",
            style=select_style,
            width="100%",
        ),
        rx.box(
            rx.text("Get Odds", color="white", font_size="0.85em", font_weight="600"),
            on_click=State.run_custom_prediction,
            width="100%", padding_y="10px",
            background_color="#FF4B4B", border_radius="6px",
            text_align="center", cursor="pointer",
        ),
        rx.cond(
            State.custom_result.length() > 0,
            rx.vstack(
                rx.box(height="1px", width="100%", background_color="#1e1e1e"),
                rx.foreach(State.custom_result.to(list[dict[str, Any]]), match_card),
                width="100%",
                spacing="2",
                padding_top="8px",
            ),
            rx.box(),
        ),
        width="100%",
        spacing="3",
    )


# ── Fixtures tab ──────────────────────────────────────────────────────────────

def fixture_edit_row(f: dict) -> rx.Component:
    s = {"background_color": "#141414", "color": "white", "border": "1px solid #2a2a2a"}
    return rx.hstack(
        rx.input(value=f["date"],      on_change=State.update_date(f["idx"]),
                 placeholder="YYYY-MM-DD", width="27%", style=s, size="1"),
        rx.input(value=f["home_team"], on_change=State.update_home_fixture(f["idx"]),
                 placeholder="Home",       width="33%", style=s, size="1"),
        rx.input(value=f["away_team"], on_change=State.update_away_fixture(f["idx"]),
                 placeholder="Away",       width="33%", style=s, size="1"),
        rx.box(
            rx.text("✕", color="#666", font_size="0.75em"),
            on_click=State.delete_fixture(f["idx"]),
            padding="5px 8px", border="1px solid #2a2a2a",
            border_radius="4px", cursor="pointer", background_color="#1a1a1a",
        ),
        align="center", width="100%", spacing="2",
    )


def fixtures_tab() -> rx.Component:
    return rx.vstack(
        rx.text("Fixtures are auto-loaded from fixtures.csv if present.",
                color="#444", font_size="0.72em"),
        rx.box(
            rx.text("Add Row", color="white", font_size="0.82em", font_weight="600"),
            on_click=State.add_fixture, width="100%", padding_y="9px",
            background_color="#1a4a2a", border_radius="6px",
            text_align="center", cursor="pointer",
        ),
        rx.foreach(State.fixtures.to(list[dict[str, Any]]), fixture_edit_row),
        rx.box(
            rx.text("Reload Predictions", color="white", font_size="0.82em", font_weight="600"),
            on_click=State.load_predictions, width="100%", padding_y="9px",
            background_color="#FF4B4B", border_radius="6px",
            text_align="center", cursor="pointer",
        ),
        width="100%", spacing="2",
    )


# ── Insights tab ──────────────────────────────────────────────────────────────

def insight_card(title: str, body: rx.Component) -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.text(title, color="#888", font_size="0.68em",
                    letter_spacing="0.1em", font_weight="700"),
            body,
            spacing="2",
            align="start",
            width="100%",
        ),
        width="100%",
        padding="12px 14px",
        background_color="#141414",
        border_radius="8px",
        border="1px solid #1e1e1e",
    )


def safe_pick_row(p: dict) -> rx.Component:
    return rx.hstack(
        badge_img(p["badge_home"], "20px"),
        rx.text(p["home_team"], color="#d0d0d0", font_size="0.8em", flex="1"),
        rx.text("v", color="#333", font_size="0.7em"),
        rx.text(p["away_team"], color="#d0d0d0", font_size="0.8em", flex="1"),
        badge_img(p["badge_away"], "20px"),
        rx.spacer(),
        rx.text(p["disp_prob_home"], color="#4CAF50", font_size="0.8em", font_weight="600"),
        width="100%",
        align="center",
        spacing="2",
    )


def coin_flip_row(p: dict) -> rx.Component:
    return rx.hstack(
        badge_img(p["badge_home"], "20px"),
        rx.text(p["home_team"], color="#d0d0d0", font_size="0.8em", flex="1"),
        rx.text("v", color="#333", font_size="0.7em"),
        rx.text(p["away_team"], color="#d0d0d0", font_size="0.8em", flex="1"),
        badge_img(p["badge_away"], "20px"),
        width="100%",
        align="center",
        spacing="2",
    )


def chart_bar_row(item: dict) -> rx.Component:
    """Manual bar chart row — home (green) / draw (yellow) / away (red) as flex widths."""
    return rx.vstack(
        rx.text(item["label"], color="#555", font_size="0.65em", letter_spacing="0.04em"),
        rx.hstack(
            rx.box(
                rx.text(item["home"], color="white", font_size="0.6em", padding_x="3px"),
                background_color="#4CAF50",
                border_radius="2px 0 0 2px",
                height="14px",
                width=item["home"].to_string() + "%",
                display="flex", align_items="center",
            ),
            rx.box(
                rx.text(item["draw"], color="white", font_size="0.6em", padding_x="3px"),
                background_color="#FFC107",
                height="14px",
                width=item["draw"].to_string() + "%",
                display="flex", align_items="center",
            ),
            rx.box(
                rx.text(item["away"], color="white", font_size="0.6em", padding_x="3px"),
                background_color="#F44336",
                border_radius="0 2px 2px 0",
                height="14px",
                width=item["away"].to_string() + "%",
                display="flex", align_items="center",
            ),
            spacing="0",
            width="100%",
        ),
        spacing="1",
        width="100%",
    )


def elo_bar_row(item: dict) -> rx.Component:
    """ELO diff bar: positive = green (home favoured), negative = red."""
    return rx.hstack(
        rx.text(item["label"], color="#555", font_size="0.65em",
                width="70px", flex_shrink="0"),
        rx.box(
            rx.text(item["elo_diff"], color="white", font_size="0.6em", padding_x="4px"),
            background_color=rx.cond(item["elo_positive"], "#4CAF50", "#F44336"),
            border_radius="3px",
            height="14px",
            min_width="28px",
            display="flex",
            align_items="center",
        ),
        width="100%",
        align="center",
        spacing="2",
    )


def insights_tab() -> rx.Component:
    return rx.vstack(
        rx.cond(
            State.predictions.length() == 0,
            rx.box(
                rx.text("Run predictions on the Home tab first.", color="#444", font_size="0.85em"),
                text_align="center", padding_y="48px", width="100%",
            ),
            rx.vstack(
                # ── Top picks ─────────────────────────────────────────────
                insight_card(
                    "HIGHEST WIN PROBABILITY",
                    rx.cond(
                        State.top_pick != {},
                        rx.hstack(
                            badge_img(State.top_pick["badge_home"], "24px"),
                            rx.text(State.top_pick["home_team"], color="#d0d0d0",
                                    font_size="0.82em", font_weight="600"),
                            rx.text("v", color="#333", font_size="0.7em"),
                            rx.text(State.top_pick["away_team"], color="#d0d0d0",
                                    font_size="0.82em"),
                            badge_img(State.top_pick["badge_away"], "24px"),
                            rx.spacer(),
                            rx.text(State.top_pick["disp_prob_home"], color="#4CAF50",
                                    font_size="0.9em", font_weight="700"),
                            width="100%", align="center", spacing="2",
                        ),
                        rx.text("—", color="#444"),
                    ),
                ),
                insight_card(
                    "BIGGEST UNDERDOG",
                    rx.cond(
                        State.underdog != {},
                        rx.hstack(
                            badge_img(State.underdog["badge_away"], "24px"),
                            rx.text(State.underdog["away_team"], color="#d0d0d0",
                                    font_size="0.82em", font_weight="600"),
                            rx.text("@", color="#333", font_size="0.7em"),
                            rx.text(State.underdog["disp_odds_away"], color="#FFC107",
                                    font_size="0.9em", font_weight="700"),
                            rx.text(State.underdog["disp_prob_away"], color="#555",
                                    font_size="0.75em"),
                            width="100%", align="center", spacing="2",
                        ),
                        rx.text("—", color="#444"),
                    ),
                ),

                # ── Confidence tiers ──────────────────────────────────────
                insight_card(
                    "SAFE PICKS  >65%",
                    rx.cond(
                        State.safe_picks.length() > 0,
                        rx.vstack(rx.foreach(State.safe_picks.to(list[dict[str, Any]]), safe_pick_row),
                                  spacing="2", width="100%"),
                        rx.text("No match clears 65% this week.", color="#555",
                                font_size="0.8em"),
                    ),
                ),
                insight_card(
                    "COIN FLIPS  (all outcomes 22–45%)",
                    rx.cond(
                        State.coin_flips.length() > 0,
                        rx.vstack(rx.foreach(State.coin_flips.to(list[dict[str, Any]]), coin_flip_row),
                                  spacing="2", width="100%"),
                        rx.text("No true coin-flip matches this week.", color="#555",
                                font_size="0.8em"),
                    ),
                ),

                # ── Win probability chart ─────────────────────────────────
                insight_card(
                    "WIN PROBABILITIES  ( H / D / A )",
                    rx.vstack(
                        rx.foreach(State.win_prob_chart.to(list[dict[str, Any]]), chart_bar_row),
                        spacing="3",
                        width="100%",
                    ),
                ),

                # ── ELO diff chart ────────────────────────────────────────
                insight_card(
                    "ELO ADVANTAGE  (home positive = home favoured)",
                    rx.vstack(
                        rx.foreach(State.elo_chart.to(list[dict[str, Any]]), elo_bar_row),
                        spacing="3",
                        width="100%",
                    ),
                ),

                width="100%",
                spacing="3",
            ),
        ),
        width="100%",
        spacing="2",
    )


# ── History tab ───────────────────────────────────────────────────────────────

def history_match_row(m: dict) -> rx.Component:
    """Row inside a saved gameweek — shows prediction + actual result selector."""
    result_style = {
        "background_color": "#0E1117",
        "color": "white",
        "border": "1px solid #2a2a2a",
        "border_radius": "4px",
        "font_size": "0.72em",
        "width": "70px",
    }
    return rx.hstack(
        badge_img(m["badge_home"], "18px"),
        rx.text(m["home_team"], color="#aaa", font_size="0.75em", flex="1",
                text_align="right", no_of_lines=1),
        rx.text("v", color="#333", font_size="0.65em"),
        rx.text(m["away_team"], color="#aaa", font_size="0.75em", flex="1",
                no_of_lines=1),
        badge_img(m["badge_away"], "18px"),
        rx.text(m["actual"], color=rx.cond(
            m["actual"] == "", "#333",
            rx.cond(m["actual"] == "H", "#4CAF50",
                    rx.cond(m["actual"] == "D", "#FFC107", "#F44336"))
        ), font_size="0.75em", font_weight="600", width="24px", text_align="center"),
        width="100%",
        align="center",
        spacing="2",
    )


def history_gw_card(entry: dict) -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.hstack(
                rx.text(entry["gw"], color="white", font_size="0.82em", font_weight="600"),
                rx.text(entry["date"], color="#444", font_size="0.72em"),
                rx.spacer(),
                rx.text(entry["accuracy"], color="#4CAF50", font_size="0.75em",
                        font_weight="600"),
                rx.text(entry["pnl"], color=rx.cond(
                        entry["pnl"] == "", "#444",
                        rx.cond(entry["pnl_positive"], "#4CAF50", "#F44336")
                ), font_size="0.75em", font_weight="600"),
                width="100%",
                align="center",
            ),
            width="100%",
            spacing="1",
        ),
        on_click=State.select_history(entry["idx"]),
        width="100%",
        padding="11px 14px",
        background_color="#141414",
        border_radius="8px",
        border="1px solid #1e1e1e",
        cursor="pointer",
    )


def history_tab() -> rx.Component:
    return rx.vstack(
        rx.cond(
            State.history.length() == 0,
            rx.box(
                rx.text("No history yet. Save a gameweek from the Home tab.",
                        color="#444", font_size="0.85em"),
                text_align="center", padding_y="48px", width="100%",
            ),
            rx.vstack(
                section_label("SAVED GAMEWEEKS"),
                rx.foreach(State.history.to(list[dict[str, Any]]), history_gw_card),
                width="100%",
                spacing="2",
            ),
        ),
        width="100%",
        spacing="2",
    )


# ── Navbar ────────────────────────────────────────────────────────────────────

NAV_ITEMS = [
    ("home",      "Home",      "home"),
    ("predictor", "Predictor", "telescope"),
    ("insights",  "Insights",  "bar-chart-2"),
    ("history",   "History",   "clock"),
]


def nav_btn(tab: str, label: str, icon: str) -> rx.Component:
    active = State.current_tab == tab
    return rx.box(
        rx.vstack(
            rx.icon(icon, size=17,
                    color=rx.cond(active, "white", "#444")),
            rx.text(label,
                    font_size="0.6em",
                    letter_spacing="0.03em",
                    font_weight=rx.cond(active, "600", "400"),
                    color=rx.cond(active, "white", "#444")),
            spacing="1",
            align="center",
        ),
        on_click=State.set_current_tab(tab),
        width="25%",
        height="56px",
        display="flex",
        align_items="center",
        justify_content="center",
        background_color=rx.cond(active, "#1a0000", "#0E1117"),
        border_top=rx.cond(active, "2px solid #FF4B4B", "2px solid transparent"),
        cursor="pointer",
    )


def navbar() -> rx.Component:
    return rx.hstack(
        *[nav_btn(tab, label, icon) for tab, label, icon in NAV_ITEMS],
        width="100%",
        spacing="0",
        position="fixed",
        bottom="0",
        left="0",
        right="0",
        z_index="1000",
        background_color="#0E1117",
        border_top="1px solid #1a1a1a",
    )


# ── Page ──────────────────────────────────────────────────────────────────────

def index() -> rx.Component:
    content = rx.cond(
        State.current_tab == "home",
        home_tab(),
        rx.cond(
            State.current_tab == "predictor",
            predictor_tab(),
            rx.cond(
                State.current_tab == "insights",
                insights_tab(),
                rx.cond(
                    State.current_tab == "history",
                    history_tab(),
                    fixtures_tab(),
                ),
            ),
        ),
    )

    return rx.box(
        rx.vstack(
            # Header
            rx.box(
                rx.heading("Premier League", size="6", color="white", font_weight="700"),
                rx.text("XGBoost + ELO · 2025/26", color="#333",
                        font_size="0.7em", letter_spacing="0.06em"),
                padding_x="16px",
                padding_top="18px",
                padding_bottom="10px",
            ),
            rx.box(height="1px", width="100%", background_color="#1a1a1a"),
            rx.box(
                content,
                width="100%",
                padding_x="16px",
                padding_bottom="80px",
                padding_top="12px",
            ),
            spacing="0",
            width="100%",
            min_height="100vh",
            background_color="#0E1117",
        ),
        navbar(),
        width="100%",
        background_color="#0E1117",
    )


app = rx.App(
    style={
        "background_color": "#0E1117",
        "color": "white",
        "font_family": "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    }
)
app.add_page(index, route="/", on_load=State.load_predictions)