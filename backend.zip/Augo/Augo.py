"""Reflex entry module.

Reflex uses `rxconfig.py: app_name` to locate the app module.
We keep the actual application implementation in top-level `app.py`,
and re-export its symbols from here so `reflex export` works reliably.
"""

from app import State, app, index  # noqa: F401

